-- =============================================================================
-- SCHEMA MIGRATION 001: Add Entity Master + Enhanced Metrics for Velo
-- =============================================================================
-- Run this ONCE before deploying Velo integration
-- Safe to run multiple times (uses IF NOT EXISTS)
-- =============================================================================

-- =============================================================================
-- PART 1: ENTITY MASTER TABLE
-- =============================================================================
-- Single source of truth for all tracked entities across all sources

CREATE TABLE IF NOT EXISTS entities (
    entity_id SERIAL PRIMARY KEY,
    
    -- Canonical identifier (your internal standard)
    canonical_id VARCHAR(100) NOT NULL UNIQUE,  -- e.g., 'solana', 'bitcoin', 'aave'
    
    -- Display info
    name VARCHAR(200) NOT NULL,                  -- e.g., 'Solana', 'Bitcoin', 'Aave'
    symbol VARCHAR(50),                          -- e.g., 'SOL', 'BTC', 'AAVE'
    
    -- Classification
    entity_type VARCHAR(50) NOT NULL DEFAULT 'token',  -- 'chain', 'protocol', 'token', 'equity'
    asset_class VARCHAR(50) NOT NULL DEFAULT 'crypto', -- 'crypto', 'equity', 'commodity'
    sector VARCHAR(100),                         -- 'l1', 'defi_lending', 'defi_dex', 'meme'
    
    -- Relationships
    parent_chain VARCHAR(100),                   -- For protocols: which chain?
    
    -- Metadata
    coingecko_id VARCHAR(100),
    created_at TIMESTAMP DEFAULT NOW(),
    is_active BOOLEAN DEFAULT TRUE
);

-- Indexes for entities
CREATE INDEX IF NOT EXISTS idx_entities_type ON entities(entity_type);
CREATE INDEX IF NOT EXISTS idx_entities_symbol ON entities(symbol);
CREATE INDEX IF NOT EXISTS idx_entities_sector ON entities(sector);

-- =============================================================================
-- PART 2: SOURCE ID MAPPING TABLE (Rosetta Stone)
-- =============================================================================
-- Maps each source's ID format to canonical entity

CREATE TABLE IF NOT EXISTS entity_source_ids (
    id SERIAL PRIMARY KEY,
    entity_id INTEGER NOT NULL REFERENCES entities(entity_id) ON DELETE CASCADE,
    source VARCHAR(100) NOT NULL,               -- 'artemis', 'defillama', 'velo'
    source_id VARCHAR(200) NOT NULL,            -- The ID that source uses
    source_id_type VARCHAR(50),                 -- 'ticker', 'slug', 'gecko_id', 'coin'
    
    UNIQUE(source, source_id)
);

CREATE INDEX IF NOT EXISTS idx_source_ids_lookup ON entity_source_ids(source, source_id);
CREATE INDEX IF NOT EXISTS idx_source_ids_entity ON entity_source_ids(entity_id);

-- =============================================================================
-- PART 3: ENHANCE METRICS TABLE
-- =============================================================================
-- Add new columns for domain, exchange, and entity linking

-- Rename pulled_at to ts if it exists (optional - skip if you prefer pulled_at)
-- ALTER TABLE metrics RENAME COLUMN pulled_at TO ts;

-- Add domain column (fundamental, trading, derivative, options)
ALTER TABLE metrics ADD COLUMN IF NOT EXISTS domain VARCHAR(50);

-- Add exchange column (for derivatives where exchange matters)
ALTER TABLE metrics ADD COLUMN IF NOT EXISTS exchange VARCHAR(100);

-- Add entity_id link (nullable for gradual migration)
ALTER TABLE metrics ADD COLUMN IF NOT EXISTS entity_id INTEGER REFERENCES entities(entity_id);

-- Add granularity column to distinguish hourly vs daily data
-- This is CRITICAL for cross-source queries
ALTER TABLE metrics ADD COLUMN IF NOT EXISTS granularity VARCHAR(20) DEFAULT 'daily';

-- Backfill existing data as 'daily' (Artemis/DefiLlama)
UPDATE metrics SET granularity = 'daily' WHERE granularity IS NULL;

-- =============================================================================
-- PART 4: UPDATE UNIQUE CONSTRAINT
-- =============================================================================
-- The new constraint includes exchange (with COALESCE for NULL handling)
-- This allows: BTC + FUNDING_RATE + binance-futures AND BTC + FUNDING_RATE + bybit
-- as separate rows

-- Drop old constraint if exists (may fail if different name - that's OK)
DROP INDEX IF EXISTS idx_metrics_unique;

-- Create new constraint that handles exchange
CREATE UNIQUE INDEX IF NOT EXISTS idx_metrics_unique 
ON metrics (source, asset, metric_name, pulled_at, COALESCE(exchange, ''));

-- =============================================================================
-- PART 5: ADD TIMESTAMP INDEX
-- =============================================================================
-- Critical for hourly data queries - avoids mixing hourly and daily data

CREATE INDEX IF NOT EXISTS idx_metrics_ts ON metrics(pulled_at);
CREATE INDEX IF NOT EXISTS idx_metrics_domain ON metrics(domain, pulled_at);
CREATE INDEX IF NOT EXISTS idx_metrics_entity ON metrics(entity_id, metric_name, pulled_at);
CREATE INDEX IF NOT EXISTS idx_metrics_exchange ON metrics(exchange, pulled_at) WHERE exchange IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_metrics_granularity ON metrics(granularity, pulled_at);

-- =============================================================================
-- PART 6: UPDATE PULLS TABLE (Optional enhancement)
-- =============================================================================

ALTER TABLE pulls ADD COLUMN IF NOT EXISTS notes TEXT;

-- =============================================================================
-- PART 7: USEFUL VIEWS
-- =============================================================================

-- Cross-source entity view: Get all data for an entity regardless of source
CREATE OR REPLACE VIEW v_entity_metrics AS
SELECT 
    e.canonical_id,
    e.name,
    e.symbol,
    e.entity_type,
    e.sector,
    m.pulled_at as ts,
    m.source,
    m.metric_name,
    m.value,
    m.domain,
    m.exchange
FROM metrics m
JOIN entity_source_ids esi ON m.source = esi.source AND m.asset = esi.source_id
JOIN entities e ON esi.entity_id = e.entity_id;

-- Derivatives summary view
CREATE OR REPLACE VIEW v_derivatives_summary AS
SELECT 
    e.canonical_id,
    e.symbol,
    m.exchange,
    DATE_TRUNC('hour', m.pulled_at) as ts,
    MAX(CASE WHEN m.metric_name = 'FUNDING_RATE' THEN m.value END) as funding_rate,
    MAX(CASE WHEN m.metric_name = 'DOLLAR_OI_CLOSE' THEN m.value END) as open_interest_usd,
    MAX(CASE WHEN m.metric_name = 'LIQ_DOLLAR_VOL' THEN m.value END) as liquidations_usd
FROM metrics m
JOIN entity_source_ids esi ON m.source = esi.source AND m.asset = esi.source_id
JOIN entities e ON esi.entity_id = e.entity_id
WHERE m.domain = 'derivative'
GROUP BY e.canonical_id, e.symbol, m.exchange, DATE_TRUNC('hour', m.pulled_at);

-- =============================================================================
-- CRITICAL: Daily aggregation of hourly Velo data for cross-source comparison
-- =============================================================================
-- Use this view when comparing Velo derivatives data with daily Artemis/DefiLlama data

CREATE OR REPLACE VIEW v_velo_daily AS
SELECT 
    DATE_TRUNC('day', pulled_at) as ts,
    source,
    asset,
    entity_id,
    metric_name,
    exchange,
    domain,
    -- Aggregation depends on metric type
    CASE 
        -- For OHLC: open = first, close = last, high = max, low = min
        WHEN metric_name = 'OPEN_PRICE' THEN (ARRAY_AGG(value ORDER BY pulled_at ASC))[1]
        WHEN metric_name = 'CLOSE_PRICE' THEN (ARRAY_AGG(value ORDER BY pulled_at DESC))[1]
        WHEN metric_name LIKE '%_HIGH' THEN MAX(value)
        WHEN metric_name LIKE '%_LOW' THEN MIN(value)
        WHEN metric_name LIKE 'HIGH_%' THEN MAX(value)
        WHEN metric_name LIKE 'LOW_%' THEN MIN(value)
        -- For OI: use end-of-day (last value)
        WHEN metric_name LIKE '%OI_CLOSE' THEN (ARRAY_AGG(value ORDER BY pulled_at DESC))[1]
        WHEN metric_name LIKE '%OI_HIGH' THEN MAX(value)
        WHEN metric_name LIKE '%OI_LOW' THEN MIN(value)
        -- For volumes, liquidations, trades: sum
        WHEN metric_name LIKE '%VOLUME%' THEN SUM(value)
        WHEN metric_name LIKE '%LIQ%' THEN SUM(value)
        WHEN metric_name LIKE '%TRADES%' THEN SUM(value)
        WHEN metric_name LIKE '%LIQUIDATIONS%' THEN SUM(value)
        -- For rates: use time-weighted average (simple avg for now)
        WHEN metric_name IN ('FUNDING_RATE', 'FUNDING_RATE_AVG', 'PREMIUM') THEN AVG(value)
        -- Default: last value
        ELSE (ARRAY_AGG(value ORDER BY pulled_at DESC))[1]
    END as value,
    COUNT(*) as hours_in_day
FROM metrics
WHERE source = 'velo' AND granularity = 'hourly'
GROUP BY DATE_TRUNC('day', pulled_at), source, asset, entity_id, metric_name, exchange, domain;

-- Unified daily view: combines daily sources with aggregated Velo
CREATE OR REPLACE VIEW v_metrics_daily AS
SELECT ts, source, asset, entity_id, metric_name, value, domain, exchange
FROM (
    -- Daily data from Artemis/DefiLlama (already daily granularity)
    SELECT 
        DATE_TRUNC('day', pulled_at) as ts,
        source, asset, entity_id, metric_name, value, domain, exchange
    FROM metrics 
    WHERE granularity = 'daily'
    
    UNION ALL
    
    -- Aggregated daily data from Velo
    SELECT ts, source, asset, entity_id, metric_name, value, domain, exchange
    FROM v_velo_daily
) combined;

-- Latest metrics per entity (useful for dashboards)
CREATE OR REPLACE VIEW v_latest_metrics AS
SELECT DISTINCT ON (m.source, m.asset, m.metric_name, m.exchange)
    e.canonical_id,
    m.source,
    m.asset,
    m.metric_name,
    m.exchange,
    m.pulled_at as ts,
    m.value,
    m.domain
FROM metrics m
LEFT JOIN entity_source_ids esi ON m.source = esi.source AND m.asset = esi.source_id
LEFT JOIN entities e ON esi.entity_id = e.entity_id
ORDER BY m.source, m.asset, m.metric_name, m.exchange, m.pulled_at DESC;

-- =============================================================================
-- VERIFICATION QUERIES (run after migration)
-- =============================================================================
-- SELECT COUNT(*) FROM entities;
-- SELECT COUNT(*) FROM entity_source_ids;
-- SELECT column_name FROM information_schema.columns WHERE table_name = 'metrics';
-- \d+ metrics
